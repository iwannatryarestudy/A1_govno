#!/data/data/com.termux/files/usr/bin/sh
adb kill-server &
sleep 5
adb start-server;
