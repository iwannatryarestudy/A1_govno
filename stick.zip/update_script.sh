#!/data/data/com.termux/files/usr/bin/sh
#
rm -rf A1_govno;
git clone https://github.com/iwannatryarestudy/A1_govno.git;
unzip -o A1_govno/stick.zip;
https://voka.tv/apps/Voka-prod-androidTv-app-default-release-21931.apk;
