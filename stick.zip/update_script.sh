#!/data/data/com.termux/files/usr/bin/sh
#
git clone https://github.com/iwannatryarestudy/A1_govno.git;
unzip -o A1_govno/stick.zip;
wget https://voka.tv/apps/TvVoka-api21-prod-leanback-app-default-release-v21870.apk;
